#include <msp430.h> 

void ini_uCon();
void ini_P1_P2();
void ini_Timer0();


void main(){
	ini_uCon();
	ini_P1_P2();
	ini_Timer0();
	while(1){

	}
}

void ini_uCon(){
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

        /* Configura��o do Sistema B�sico de Clock BCS
         *
         * -> Osciladores:
         *      LFXT1CLK = 32 768 Hz
         *      VLO = N�o utilizado
         *      DCO ~ 16 MHz (via dados de calibra��o do fabricante)
         * ->Sa�das de CLK
         *      ACLK = LFXT1CLK = 32 768 Hz
         *      MCLK = DCOCLK ~ 16 MHz
         *      SMCLK = DCOCLK/8 ~ 2 MHz
         *
         * */

        DCOCTL = CALDCO_16MHZ;
        BCSCTL1 = CALBC1_16MHZ;
        BCSCTL2 = DIVS0 + DIVS1;
        BCSCTL3 = XCAP0 + XCAP1;

        while(BCSCTL3 & LFXT1OF); // sai quando oscilador atingir a frequ�ncia do cristal

        __enable_interrupt();
}

void ini_P1_P2(){
    /* Porta 1
     *      P1.0 - Led_VM - sa�da em n�vel baixo
     *      P1.3 - S2 - entrada com resistor de pull-up e int.
     *                  habilitada por borda de descida.
     *
     *      P1.x - N.C
     * */
    P1DIR = ~BIT3;
    P1REN = BIT3;       //Habilita resistor interno
    P1OUT = BIT3;       //Resistor pull-up para bit3
    P1IES = BIT3;
    P1IFG = 0;          //Limpar as flags de interrup��o
    P1IE = BIT3;        //Habilita a interrup��o somente de origem da entrada

    /* Porta 2
     *      P2.0 - P2.5 - N.C - sa�da em n�vel baixo
     *
     *      OBS.: Pinos 18 e 19: Fun��es nativas XIN e XOUT devem ser mantidas, pois utilizar-se-� o clock
     *
     * */

    P2DIR = 0xFF;
    P2OUT = 0;
}

void ini_Timer0(){
    /*  Requisito: temporiza��o de 5 ms
     *
     *  CONTADOR:
     *      -> Clock: SMCLK ~ 2MHz
     *          - Fdiv: 1 //� necess�rio dividir? S� se divide quando tb > 65536
     *                  tb =
     *      -> Modo do contador: UP (inicialmente parado)
     *      -> Int. contador: desabilitada
     *      ->
     *
     *  MODULO 0:
     *      -> Fun��o: compara��o (padr�o)
     *      -> Int.: Habilitada
     *      -> Valor para TA0CCR0: ?  //Valor que deve ser calculado (tempo*CLK)/(Fdiv) =>  5ms * 2Mhz / 1 = 10000
     *
     *  TASSELx = Setar bit1
     *  MCx : setar bit 0 para modo UP
     *  TAIE : N�o habilita interrup��o do contador. Permanece em 0
     *
     *
     *
     *
     * */
    TA0CTL = TASSEL1;
    TA0CCTL0 = CCIE;
    TA0CCR0 = 9999; // 0x2710;
}


#pragma vector=PORT1_VECTOR
__interrupt void RTI_Porta_1(){
    //P1IFG &= ~BIT3; opcional pois, como a interrup��o ser� desabilitada, n�o existe a necessidade de limpar flags

    // Passo 1: desabilita interrup��o da entrada P1.3
    P1IE &= ~BIT3;
    // Passo 2: inicia o temporizador Timer0 para 5 ms
    //          Colocar contador do T0 no modo UP, que inicialmente est� parado;
    TA0CTL |= MC0;
}

//RTI do M�dulo 0 do Timer 0

#pragma vector=TIMER0_A0_VECTOR
__interrupt void RTI_M0_T0(void){
    // Passo 3: Parar temporizador;
    TA0CTL &= ~MC0; // Coloca contador no modo PARADO

    /* Passo 4: Verifica n�vel de entrada e v�lida tecla
     *     - Se n�vel de P1.3 for BAIXO, significa que S2
     *     realmente foi pressionada. Ent�o realiza-se a
     *     a��o dessa chave.
     *     - Se n�vel de P1.3 for ALTO, S2 n�o foi
     *     pressionada. Ent�o n�o faz nada.
     *
     *      if(   P1IN & BIT3)
     *              -> entra quando a chave est� aberta
     *
     *                  bit         7 6 5 4  3 2 1 0
     *                  P1IN        X X X X  Y X X X
     *                  BIT3        0 0 0 0  1 0 0 0    AND b-a-b
     *                       _________________________
     *                              0 0 0 0  Y 0 0 0
     *
     *      if(~P1IN & BIT3)
     *              -> entra quando a chave est� fechada
     *                  bit         7 6  5  4   3  2  1  0
     *                  ~P1IN      /X /X /X /X  /Y /X /X /X
     *                  BIT3        0 0 0 0     1  0  0  0    AND b-a-b
     *                             _________________________
     *                              0 0 0 0     /Y 0  0  0
     *
     * */
    if((~P1IN) & BIT3){
        // Chave S2 realmente foi pressionada, ent�o
        // deve-se realizar a a��o da chave: alternar o
        // estado do Led_VM
        P1OUT ^= BIT0;
    }

    // Passo 5: Limpar flag de interrup��o de P1.3
    P1IFG &= ~BIT3;

    // Passo 6: Habilita interrup��o de P1.3
    P1IE |= BIT3;
}
