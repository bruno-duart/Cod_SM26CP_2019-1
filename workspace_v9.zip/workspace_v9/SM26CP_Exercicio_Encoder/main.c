#include <msp430.h> 

void ini_uCon();
void ini_P1_P2();
void ini_Timer0_Deb();
void ini_Timer1_Pisca();
unsigned int npisca = 0, count = 0;
void main(void)
{
    ini_uCon();
    ini_P1_P2();
    ini_Timer0_Deb();
    ini_Timer1_Pisca();
	while(1){

	}
}

void ini_uCon(){
    WDTCTL = WDTPW | WDTHOLD;


    DCOCTL = CALDCO_16MHZ;
    BCSCTL1 = CALBC1_16MHZ;
    BCSCTL2 = DIVS0 + DIVS1;
    BCSCTL3 = XCAP0 + XCAP1;

    while(BCSCTL3 & LFXT1OF);

    __enable_interrupt();
}

void ini_P1_P2(){
    /* Inicializa��o da PORTA 1
     *
     *      P1.0 - LED VM - sa�da em n�vel baixo
     *      P1.6 - LED VD - sa�da em n�vel baixo
     *      P1.x - n.c
     * */
    P1DIR = 0xFF;
    P1OUT = 0;

    /*  Inicializa��o da PORTA 2
     *
     *      P2.0 - Sa encoder - Entrada c/ resistor de pull-up e
     *                          interrup��o por borda de descida
     *
     *      P2.1 - Sb encoder = Entrada c/ resistor de pull-up
     *      P2.x - n.c.
     *
     * */

    P2DIR = ~(BIT0 + BIT1);
    P2OUT = BIT0 + BIT1;
    P2IES = BIT0;
    P2IFG = 0;
    P2IE = BIT0;
}

void ini_Timer0_Deb(){
    /* -> Temporizador de ~ 1ms
     *
     * Contador:
     *      - Clock: SMCLK ~ 2MHz
     *          -> Fdiv: 1
     *      - Modo: UP (inicialmente parado)
     *      - Interrup��o contador: desabilitada
     *
     * M�dulo 0:
     *      - Fun��o compara��o (nativa)
     *      - Interrup��o habilitada
     *      - Valor para TA0CCR0
     *          -> Depende do clock escolhido
     *          -> TACCRO = (0,001 * 2M) = 2000
     * */

    TA0CTL = TASSEL1;
    TA0CCTL0 = CCIE;
    TA0CCR0 = 2000;
}


#pragma vector=PORT2_VECTOR
__interrupt void RTI_da_Porta2(){
    P2IE &= ~BIT0;

    // Passo 2. Iniciar Temporizador
    TA0CTL |= MC0;
}

#pragma vector=TIMER0_A0_VECTOR
__interrupt void RTI_M0_Timer0(){
    // 1 - Parar temporizador
    TA0CTL &= ~MC0;

    /* 2 - Verificar se P2.0 est� em n�vel baixo
     *      - Verificar sentido de giro
     * */

    if((~P2IN) & BIT0){
         if(P2IN & BIT1){ //Sentido hor�rio
            if(count >= 10)
                count = 0;
            else
                count++;
         }
         else{           // Sentido anti-hor�rio
             if(count <= 0)
                count = 0;
             else{
                 count--;
             }
         }
         TA1CTL |= MC0;
         npisca = count << 1; // Deslocamento de bit (dobra o valor)
    }

    P2IFG = 0;
    P2IE |= BIT0;
}


#pragma vector=PORT1_VECTOR
__interrupt void RTI_M0_Timer1(){
    if(npisca == 0){
        TA1CTL &= ~MC0;
    }
    else{
        npisca--;
        P1OUT &= ~BIT0;
    }
}

void ini_Timer1_Pisca(){
    /* Inicializa��o do Timer 1
     *
     * -> Temporiza��o t ~ 20 ms
     *
     * Contador:
     *      - Clock: ACLK
     *          -> Fdiv = 1
     *      - Modo: UP (inicialmente parado)
     *      - int. desabilitada
     *
     * Modulo 0:
     *      - Fun��o: compara��o
     *      - int: habilitada
     *      - TA0CCR0 = (0,02 * 32768) - 1
     * */

    TA1CTL = TASSEL0;
    TA1CCTL0 = CCIE;
    TA1CCR0 = 655;

}
