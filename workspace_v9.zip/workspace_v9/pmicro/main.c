/*
*
*
* - Timer 0: Temporizacao para envio de dados a leds
*
* - Timer 1: Medicao de rotacao do motor - Modo Captura
*
* Pino 8 - P2.0 -> Timer1_A3_CCI0A
*
*
*
*/


#include <msp430.h>

typedef unsigned char u_char;
typedef unsigned int u_int;
int cont, index, dt;
short select = 0;
typedef struct {
    u_char r;
    u_char g;
    u_char b;
} RGBLED;
#define DATA_OUT_PIN BIT7
void sendRGB(u_char numberOfLEDs);
RGBLED data[11] = { 0, };


void config_ini(void);
void ini_P1_P2(void);
void ini_Timer1_Cap(void);
void ini_Timer0(void);
void sendRGB(u_char numberOfLEDs);


unsigned int cap_atual = 0, cap_anterior = 0;
unsigned long contagens = 4096;
unsigned char i = 0;

unsigned int count_ciclos =0;

//-----------------------------------------------------------------------------
void main(void){
   config_ini();
    ini_P1_P2();
    ini_Timer1_Cap();
    ini_Timer0();

    while(1);

}
//-----------------------------------------------------------------------------

#pragma vector=PORT1_VECTOR
__interrupt void RTI_P1(void){ // Altera a mensagem
    TA0CCTL1 |= CCIE;
}

#pragma vector=TIMER0_A1_VECTOR
__interrupt void RTI_TIMER0_DEBOUNCER(void){
    TA0CCTL1 &= ~CCIE;
    if(~P1IN & BIT3){
        if(select == 2){
            select = 0;
        }
        else if (select == 0){
            select = 1;
        }
        else{
            select = 2;
        }
        P1IFG &= ~BIT3;
    }
}

// RTI do M0 do Timer 0
#pragma vector=TIMER0_A0_VECTOR
__interrupt void interrupcaoTimer(void){

    if(select == 0){ // mensagem 1
        for(cont=0; cont<11; cont++){
            data[cont].r = 0;
            data[cont].g = 0;
            data[cont].b = 255;
        }
    }else if (select == 1){ // mensagem 2
        for(cont=0; cont<11; cont++){
            data[cont].r = 255;
            data[cont].g = 0;
            data[cont].b = 0;
        }
    }else{ // mensagem 3
        for(cont=0; cont<11; cont++){
            data[cont].r = 0;
            data[cont].g = 0;
            data[cont].b = 0;
        }
    }
    sendRGB(11);
}

// RTI do M0 do Timer 1
#pragma vector=TIMER1_A0_VECTOR
__interrupt void Timer1A_CC0_RTI(void){

    cap_atual = TA1CCR0;

    if(i == 1){
        if(count_ciclos > 1){
            contagens = 65536 - cap_anterior + ((count_ciclos - 1)*65536) + cap_atual;
            count_ciclos = 0;

        }else{
            if(cap_atual < cap_anterior){
                contagens = (65536 - cap_anterior) + cap_atual;
            }else{
                contagens = cap_atual - cap_anterior;
            }
            count_ciclos = 0;
        }
        if(contagens < 4096) contagens = 4096;
        //else if(contagens > 65536) contagens = 65536; // professor falou pra colocar (remover??)
        TA0CCR0 = contagens >> 6; // Atualiza tempo / divide por 64
    }
    cap_anterior = cap_atual;
    i = 1;
}

// RTI do cONTADOR do Timer 1
#pragma vector=TIMER1_A1_VECTOR
__interrupt void Timer1A_CCC_RTI(void){
      (void)TA1IV;
      count_ciclos++;

}


void ini_Timer1_Cap(void){

    /*
    * Clock: SMCLK ~ 2 MHz
    * - Fdiv: 8
    * - Clock: 250 kHz
    *
    * - Resol.: 4 us * 65536 ~ 262 ms
    *
    *
    */
    TA1CTL = TASSEL1 + ID0 + ID1 + MC1 + TAIE;
    TA1CCTL0 = CM0 + CAP + CCIE;
}

void ini_Timer0(void){
    /* -> Usado para estabelecer o periodo de atualizacao dos leds
    *
    * Clock: SMCLK ~ 2 MHz
    * - Fdiv: 8
    * - Clock: 250 kHz
    *
    * MODULO 0:
    * - Funcao: comparacao
    * - int. habilitada
    * - TA0CCR0 = contagens / N; N-> num. de intervalos dentro do
    * periodo de 1 giro. N = 64 para ang. ~ 5 graus
    *
    *
    */
    TA0CTL = TASSEL1 + ID0 + ID1 + MC0;
    TA0CCTL0 = CCIE;
    TA0CCR0 = 4096; // Tinicial ~ 16 ms

    TA0CCR1 = 50000;
    TA0CCTL1 = ~CCIE;
}

void ini_P1_P2(void){
    P1DIR = ~BIT3;
    P1OUT = BIT6 + BIT3;
    P1REN = BIT3;
    P1IES = BIT3;
    P1IFG &= ~BIT3;
    P1IE = BIT3;
    P1SEL |= DATA_OUT_PIN;
    P1SEL2 |= DATA_OUT_PIN;

    P2DIR = ~BIT0;
    P2OUT = 0;
    P2SEL |= BIT0; // P2.0 -> Timer1_A3_CCI0A

    UCB0CTL0 |= UCCKPH + UCMSB + UCMST + UCSYNC; // 3-pin, 8-bit SPI master
    UCB0CTL1 |= UCSSEL_2; // SMCLK
    UCB0BR0 |= 0x03; // 1:3 - 16MHz/3 = 0.1875us
    UCB0BR1 = 0;
    UCB0CTL1 &= ~UCSWRST;
}

void config_ini(void){

    WDTCTL = WDTPW | WDTHOLD; // Para o contador do watchdog timer

    // Configuracoes do BCS
    // MCLK = DCOCLK ~ 16 MHz
    // ACLK = LFXT1CLK = NAO CONFIG.
    // SMCLK = DCOCLK / 8 ~ 2 MHz

    DCOCTL = CALDCO_16MHZ; // Freq. Calibrada de 16 MHz
    BCSCTL1 = CALBC1_16MHZ;
    //BCSCTL2 = DIVS0 + DIVS1; // Fator divisao = 8 para SMCLK

    __enable_interrupt(); // seta o bit GIE - permite geracao de interrupcoes
}


void sendRGB(u_char numberOfLEDs) {
    u_int c = 0;
    u_char led = 0;
    u_char leds[3];
    u_char d;

    //__disable_interrupt(); // seta o bit GIE - permite geracao de interrupcoes

    while (c < numberOfLEDs) {
        leds[0] = data[c].g;
        leds[1] = data[c].r;
        leds[2] = data[c].b;
        while (led < 3) {
            u_char b = 0;
            d = leds[led];
            while (b < 8) {
                while (!(IFG2 & UCB0TXIFG));
                (d & 0x80) ? (UCB0TXBUF = 0xF0) : (UCB0TXBUF = 0xC0);
                d <<= 1;
                b++;
            }
            led++;
        }
        led = 0;
        c++;
    }
    //__enable_interrupt(); // seta o bit GIE - permite geracao de interrupcoes

    __delay_cycles(800); // delay 50us to latch data, may not be necessary
}
