#include <msp430.h> 

void ini_uCon(void);
void ini_P1_P2(void);
void ini_Timer0_PWM_ADC10(void);
void ini_ADC10(void);

unsigned int res_conv = 0;
double Tc = 0.0;

void main(void)
{
    ini_uCon();
    ini_P1_P2();
    ini_Timer0_PWM_ADC10();
    ini_ADC10();
	while(1){
	    __bis_SR_register(LPM0_bits + GIE);
	}
}

//----------------------------------------------------------------

#pragma vector=ADC10_VECTOR
__interrupt void ADC10_RTI(void){
    ADC10CTL0 &= ~ENC;

    res_conv = ADC10MEM;

    Tc = (0.413 * (double)res_conv) - 277.87;

    ADC10CTL0 |= ENC;
}

//----------------------------------------------------------------
void ini_uCon(void){

    WDTCTL = WDTPW | WDTHOLD;
     //MCLK = 16MHz
     //SMCLK = 8MHz
     //ACLK = 32.768Hz

     DCOCTL = CALDCO_16MHZ;
     BCSCTL1 = CALBC1_16MHZ;
     BCSCTL2 = DIVS0;       // Fdiv = 2
     BCSCTL3 = XCAP0 + XCAP1; //Inicializa��o padr�o, n�o utilizado nesse exerc�cio.

     while(BCSCTL3 & LFXT1OF);

     __enable_interrupt();
}

void ini_P1_P2(void){
    P1DIR = 0xFF;
    P1OUT = 0;

    P2DIR = 0xFF;
    P2OUT = 0;
}

void ini_Timer0_PWM_ADC10(void){
    TA0CTL = TASSEL0 + MC0;
    TA0CCTL1 = OUTMOD0 + OUTMOD1 + OUTMOD2 + OUT;
    TA0CCR0 = 32767;
    TA0CCR1 = 16383;
}

void ini_ADC10(void){
    ADC10CTL0 = SREF0 + ADC10SHT0 + ADC10SHT1 + ADC10SR + REFBURST + REFON + ADC10ON + ADC10IE;
    ADC10CTL1 = INCH1 + INCH3 + SHS0 + ADC10DIV2;
    ADC10CTL0 |= ENC;
}
