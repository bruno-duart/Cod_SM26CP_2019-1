#include <msp430.h> 
#include <stdio.h>

void ini_uCon(void);
void ini_P1_P2();
void ini_USCI_A0_UART();

unsigned char TX_DATA[32], RX_DATA[32];
unsigned char tx_index = 0;
unsigned char rx_index = 0;
//double temperatura = 32.5;

void main(void){
    ini_uCon();
	ini_P1_P2();
	ini_USCI_A0_UART();
	long i;

	//sprintf(&TX_DATA[0],"Temperatura = %f\n", temperatura);

	while(1){
	    UCA0TXBUF = TX_DATA[tx_index];
	    tx_index++;
	    for(i = 0; i < 1000000; i++);
	}
}

#pragma vector=USCIAB0RX_VECTOR
__interrupt void RTI_TX_UART(){
    IFG2 &= ~UCA0TXIFG;

    if(TX_DATA[tx_index] == '\0')
        tx_index = 0;
    else{
        tx_index++;
        UCA0TXBUF = TX_DATA[tx_index];
    }
}

#pragma vector=USCIAB0RX_VECTOR
__interrupt void RTI_RX_UART(){
    RX_DATA[rx_index] = UCA0RXBUF;
    if(rx_index >= 31)
        rx_index = 0;
    else
        rx_index++;
}

void ini_USCI_A0_UART(){
    /* USCI A0 configurada no modo UART
     *      - Taxa: 9600 bps
     *      - Stop bit: 1
     *      - Paridade: nenhuma
     *
     *      - Clock: SMCLK ~ 8 MHz
     *      - Interrup��es: TX e RX habilitadas
     *      - Sobreamostragem: N�o
     *
     *
     *
     *
     * */

    UCA0CTL1 |= UCSWRST;
    UCA0CTL0 = 0;
    UCA0CTL1 = UCSSEL1 + UCSWRST; // Fonte clock: SMCLK ~ 8 MHz
    UCA0BR0 = 0x41; // Para 9600 bps, conforme Tabela 15-4 do User Guide
    UCA0BR1 = 0x03;
    UCA0MCTL = UCBRS1;
    UCA0CTL1 &= ~UCSWRST; // Coloca a interface no modo normal
    IFG2 &= ~UCA0TXIFG; // Limpa TXIFG, pois o bit � setado ap�s reset
    IE2 |= UCA0TXIE + UCA0RXIE; // Habilitando a gera��o de int. para RX e TX

}

void ini_uCon(void){
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    /* Configura��o do Sistema B�sico de Clock BCS
    *
    * -> Osciladores:
    *      LFXT1CLK = 32 768 Hz
    *      VLO = N�o utilizado
    *      DCO ~ 16 MHz (via dados de calibra��o do fabricante)
    * ->Sa�das de CLK
    *      ACLK = LFXT1CLK = 32 768 Hz
    *      MCLK = DCOCLK ~ 16 MHz
    *      SMCLK = DCOCLK/2 ~ 8 MHz
    *
    * */
    DCOCTL = CALDCO_16MHZ;
    BCSCTL1 = CALBC1_16MHZ;
    BCSCTL2 = DIVS0;
    BCSCTL3 = XCAP0 + XCAP1;

    while(BCSCTL3 & LFXT1OF);

    __enable_interrupt();
}

void ini_P1_P2(){
    P1DIR = 0xFF;
    P1OUT = 0;

    P2DIR = 0xFF;
    P2OUT = 0;
}
