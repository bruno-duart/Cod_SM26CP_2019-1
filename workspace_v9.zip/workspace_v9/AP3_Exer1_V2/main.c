#include <msp430.h>

void ini_uCon(void);
void ini_P1_P2(void);
void ini_TA0(void);
void ini_TA1(void);

unsigned char dec_seg = 0, cent_seg = 0, seg = 0, min = 0, aux = 0;

//MAIN
void main(void) {
    ini_uCon();
    ini_P1_P2();
    ini_TA0();
    ini_TA1();

    do{
        if (aux == 0){
            cent_seg = 0;
            dec_seg = 0;
            seg = 0;
            min = 0;
        }
    }while(1);
}

//CONFIGURACOES INICIAIS
void ini_uCon(void){
    WDTCTL = WDTPW | WDTHOLD;  // Stop watchdog timer

    //Configuracao do BCS
    //MCLK = 8MHz
    //SMCLK = 1MHz
    //ACLK = 32768Hz

    DCOCTL = CALDCO_1MHZ;
    BCSCTL1 = CALBC1_1MHZ;
    BCSCTL2 = DIVS1 + DIVS0;
    BCSCTL3 = XCAP1 + XCAP0;

    while(BCSCTL3 & LFXT1OF);   //Sai do loop quando LFXT1CLK estiver estavel

    __enable_interrupt();
}

//CONFIGURACOES DAS PORTAS
void ini_P1_P2(void){
    P1DIR = ~BIT3;      //Bit 3 como entrada e resto como saida
    P1OUT = BIT3;       //Bit 3 com pull up e saidas em nivel logico baixo
    P1REN = BIT3;       //Habilita resistor pro Bit 3
    P1IES = BIT3;      //Interrupcao por borda de descida
    P1IFG = 0x00;       //Limpa flags
    P1IE = BIT3;        //Habilita geracao de interrupcao para o bit 3
    P2DIR = 0xFF;       //P2 tudo como saida
    P2OUT = 0x00;       //Saidas em nivel logico baixo
}

//CONFIGURACOES DO TIMER A
void ini_TA1(void){

    TA1CTL = TASSEL1; // Fonte ACLK + Modo Up
    TA1CCTL0 = CCIE;
    TA1CCR0 = 9999;
}
void ini_TA0(void){
    TA0CTL = TASSEL0 + MC0;  // Fonte ACLK + Modo Up
    TA0CCTL0 = CCIE;
    TA0CCR0 = 327;  // Interrupcoes a cada ~10ms (327/32768)
}

//RTI DA PORTA 1
#pragma  vector=PORT1_VECTOR
__interrupt void P1_RTI(void){

    P1IE &= ~BIT3;  //Desabilita a interrupcao do bit 3 porta 1
    P1IFG &= ~BIT3; //Limpa a flag do bit 3 da porta 1

    TA1CTL |= MC0;
}

// RTI do TIMER A1
#pragma  vector=TIMER1_A0_VECTOR
__interrupt void  RTI_do_Mod0_do_Timer1(void){

    TA1CTL &= ~MC0;
    if( (~P1IN) & ~BIT3 ) {
        aux ++; // Tecla valida! entao acresce auxiliar

        if (aux == 1){
            P1OUT |= BIT6;
            P1OUT &= ~BIT0;
        }
        if (aux == 2){
            P1OUT |= BIT0;
            P1OUT &= ~BIT6;
        }
        if (aux == 3){
            P1OUT &= ~BIT6;
            P1OUT &= ~BIT0;
            aux = 0;
        }
    }
    P1IE = BIT3;  // Interrupcao do BIT3 da P1 habilitada

}

// RTI DO TIMER A0
#pragma  vector=TIMER0_A0_VECTOR
__interrupt void TimerA0_RTI(void){
    if (aux == 1){
        cent_seg ++;
        if (cent_seg == 10){
            cent_seg = 0;
            dec_seg++;
        }
        if (dec_seg == 20){
            dec_seg = 0;
            seg++;
        }
        if (seg == 60){
            seg = 0;
            min++;
        }
        if (min == 60){
            aux++;
        }
    }
    else if (aux == 2){
        //MANTER A CONTAGEM PARADA
    }
}
