#include <msp430g2553.h>
#include <stdlib.h>
typedef unsigned char u_char;
typedef unsigned int u_int;
int cont, cor, graus;
typedef struct {
    u_char r;
    u_char g;
    u_char b;
} RGBLED;
void init(void);
#define DATA_OUT_PIN BIT7
void sendRGB(u_char numberOfLEDs);
RGBLED data[10] = { 0, }; // 0.5m strip

void main(void) {
    init();
    RGBLED amarelo={255,255,0};
    RGBLED verde={0,255,0};
    RGBLED vermelho={255,0,0};
    RGBLED blu={0, 0, 255};
    RGBLED preto={0,0,0};


    while (1) {
        for(graus=0; graus<64; graus++){
            if(graus==0 || graus==4 || graus == 8 || graus == 12 || graus == 18 || graus == 24)
                for(cont=0; cont<10; cont++){
                    if(cont>=0 && cont <= 4)
                        data[cont]=preto;
                    else
                        data[cont]=amarelo;
                }
            else if(graus>=1 && graus<=3)
                for(cont=0; cont<10; cont++){
                    if(cont==5 || cont==4)
                        data[cont]=amarelo;
                    else
                        data[cont]=preto;
                }
            else if((graus >= 6 && graus <= 7) ||(graus == 9 || graus == 10) || (graus >= 15 && graus <= 16))
                for(cont=0; cont<10; cont++){
                    if(cont==9)
                        data[cont]=amarelo;
                    else
                        data[cont]=preto;
                }
            else if(graus == 13 || graus == 14 || graus == 25 || graus == 26 || (graus >= 19 && graus <= 21))
                for(cont=0; cont<10; cont++){
                    if(cont==9 || cont == 7)
                        data[cont]=amarelo;
                    else
                        data[cont]=preto;
                }
            else if (graus ==  22){
                for(cont=0; cont<10; cont++){
                    if(cont==9 || cont == 8 || cont == 7)
                        data[cont]=amarelo;
                    else
                        data[cont]=preto;
                }
            }
            else if(graus == 27){
                for(cont=0; cont<10; cont++){
                    if(cont==9 || cont == 7 || cont == 6)
                        data[cont]=amarelo;
                    else
                        data[cont]=preto;
                }
            }
            else if (graus == 28){
                for(cont=0; cont<10; cont++){
                    if(cont==9 || cont ==8 || cont == 7 || cont == 5)
                        data[cont]=amarelo;
                    else
                        data[cont]=preto;
                }
            }
            else{
                for(cont=0; cont<10; cont++){
                    data[cont]=preto;
                }
            }
            sendRGB(10);
            __delay_cycles(50500);
        }
    }
}

void init(){
    WDTCTL = WDTPW + WDTHOLD;
    BCSCTL1 = CALBC1_16MHZ;
    DCOCTL = CALDCO_1MHZ;
    P1SEL |= DATA_OUT_PIN;
    P1SEL2 |= DATA_OUT_PIN;
    UCB0CTL0 |= UCCKPH + UCMSB + UCMST + UCSYNC; // 3-pin, 8-bit SPI master
    UCB0CTL1 |= UCSSEL_2; // SMCLK
    UCB0BR0 |= 0x03; // 1:3 - 16MHz/3 = 0.1875us
    UCB0BR1 = 0;
    UCB0CTL1 &= ~UCSWRST;
}
void sendRGB(u_char numberOfLEDs) {
    u_int c = 0;
    u_char led = 0;
    u_char leds[3];
    u_char d;
    while (c < numberOfLEDs) {
        leds[0] = data[c].g;
        leds[1] = data[c].r;
        leds[2] = data[c].b;
        while (led < 3) {
            u_char b = 0;
            d = leds[led];
            while (b < 8) {
                while (!(IFG2 & UCB0TXIFG));
                (d & 0x80) ? (UCB0TXBUF = 0xF0) : (UCB0TXBUF = 0xC0);
                d <<= 1;
                b++;
            }
            led++;
        }
        led = 0;
        c++;
    }
    __delay_cycles(800); // delay 50us to latch data, may not be necessary
}

/*for(cor=0; cor<10; cor++)
    for(cont =0; cont<255; cont+=30){
        data[cor].r = cont;
        data[cor].g = cont;
        data[cor].b = cont;
        sendRGB(10);
        __delay_cycles(20000);
    }
for(cor=0; cor<10; cor++)
    for(cont =255; cont>=0; cont-=15){
        data[cor].r = cont;
        data[cor].g = cont;
        data[cor].b = cont;
        sendRGB(10);
        __delay_cycles(20000);
    }
for(cont=0; cont<10; cont++){
    if(cont%2==1){
        data[cont].r = 0;
        data[cont].g = 255;
        data[cont].b = 127;
    }
    else{
        data[cont].r = 255;
        data[cont].g = 140;
        data[cont].b = 0
                ;
    }
    sendRGB(10);
    //__delay_cycles(2000000);
}
__delay_cycles(2000000);
for(cont=0; cont<10; cont++){
    if(cont%2==1){
        data[cont].r = 255;
        data[cont].g = 0;
        data[cont].b = 0;
    }
    else{
        data[cont].r = 176;
        data[cont].g = 224;
        data[cont].b = 230;
    }
    sendRGB(10);
    //__delay_cycles(2000000);
}
__delay_cycles(2000000);*/
