#include <msp430.h> 

void ini_P1_P2();
void ini_uCon();
void ini_Timer0();

void main(void){

    ini_uCon();
    ini_P1_P2();
    ini_Timer0();
	do{
	    // loop vazio
	    // Op��o: desligar CPU para economizar energia (LFM0)

	    __bis_SR_register(LPM0_bits + GIE);
	}while(1);
}

void ini_uCon(){
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    /* Configura��o do Sistema B�sico de Clock BCS
     *
     * -> Osciladores:
     *      LFXT1CLK = 32 768 Hz
     *      VLO = N�o utilizado
     *      DCO ~ 16 MHz (via dados de calibra��o do fabricante)
     * ->Sa�das de CLK
     *      ACLK = LFXT1CLK = 32 768 Hz
     *      MCLK = DCOCLK ~ 16 MHz
     *      SMCLK = DCOCLK/8 ~ 2 MHz
     *
     * */

    DCOCTL = CALDCO_16MHZ;
    BCSCTL1 = CALBC1_16MHZ;
    BCSCTL2 = DIVS0 + DIVS1;
    BCSCTL3 = XCAP0 + XCAP1;

    while(BCSCTL3 & LFXT1OF); // sai quando oscilador atingir a frequ�ncia do cristal

    __enable_interrupt();
}

void ini_P1_P2(){
    /* Todos os bits de P1 como sa�da, e inicialmente em n�vel baixo
     * */
    P1DIR = 0xFF;
    P1OUT = BIT0;

    /* P2.x - N.C - sa�das em n�vel baixo
     *
     * Pinos 18 e 19 n�o ter�o suas fun��es alteradas, pois o oscilador LFXT1 ser�
     * utilizado. Assim as fun��es XIN e XOUT devem ser mantidas.
     *
     * */
    P2DIR = 0xFF;
    P2OUT = 0;
}

 void ini_Timer0(){
     /* Inicializa��o do Timer 0
      *
      * -> interrup��o temporizada de 1 segundo
      *
      * CONTADOR
      *     - Clock: ACLK
      *     - FDIV: 1
      *     - Modo do contador: UP
      *     - Interrup��o do contador: desativada pois utilizar-se-� a interrup��o do m�dulo 0
      *
      * M�DULO 0
      *     - Fun��o: compara��o
      *     - Valor para TA0CCR0 = 32 767
      *     - Int.: habilitar
      *
      *
      * */
     TA0CTL = TASSEL0 + MC0;

     TA0CCTL0 = CCIE;

     TA0CCR0 = 32767;

 }

#pragma vector=TIMER0_A0_VECTOR

__interrupt void RTI_Mod0_T0(){
    /* 1 - Precisa limpar a flag de interrup��o?
     *      R: N�o. Hardware limpa automaticamente pois s� existe uma interrup��o
     *      habilitada para o m�dulo.
     *  A CPU entra nesta RTI a cada 1 segundo
     * */

    P1OUT ^= BIT0 + BIT6;
}
