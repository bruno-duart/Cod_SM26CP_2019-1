#include <msp430.h>

void ini_P1_P2(void);
void ini_uCon(void);
void ini_timer0(void);
void ini_timer1_deb();

int X = BIT0, vel = 4000, i;

void main(void)
{
    ini_uCon();
    ini_P1_P2();
    ini_timer0();
    ini_timer1_deb();

    while(1){
        /*  N�o faz nada, a CPU fica no timer e cai no RTI a cada 1 segundo
         *
         *      Op��o: desligar a CPU para economizar energia (LPM0)
         */
        __bis_SR_register(LPM0_bits + GIE);
    }
}

void ini_P1_P2(void){
    /* PORTA 1
     *      P1.0 - LED_VM - Sa�da em n�vel baixo
     *      P1.x - N.C. - Sa�da em n�vel baixo
     *
     * PORTA 2
     *      P2.x - N.C. - sa�das em n�vel baixo
     *      pinos 18 e 19, manter a fun��o pois o oscilador LFXT1 ser� utilizado
     */
    P1DIR = 255;
    P1OUT = 0;

    P2DIR = ~(BIT0 + BIT1);
    P2REN = BIT0 + BIT1;
    P2OUT = BIT0 + BIT1;
    //P2IES = ~(BIT0 + BIT1); // tava P1
    P1IES = BIT0;
    P2IFG = 0;
    P2IE = BIT0;
}

void ini_uCon(void){
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer
    /*  Configurar o sistema b�sico de clock (BCS)
     *
     *   -> Osciladores
     *      VLO = n�o utilizado
     *      LFXT1CLK = 32768 Hz
     *      DCOCLK ~ 16MHz (via dados de calibra��o do fabricante)
     *
     *   -> Sa�das de clock
     *      ACLK  = LFXT1CLK = 32768 Hz
     *      MCLK = DCOCLK ~ 16 MHz
     *      SMCLK = DCOCLK/8 ~ 2 MHz
     */
    DCOCTL = CALDCO_16MHZ; // constante que "chama" os 16 MHz
    BCSCTL1 = CALBC1_16MHZ;
    BCSCTL2 = DIVS0 + DIVS1; // faz a divis�o por 8 do clock de 16 MHz
    BCSCTL3 = XCAP0 + XCAP1; // configura algum dole de algum capacitor

    while(BCSCTL3 & LFXT1OF); // sai quando o oscilador atingir a frequ�ncia do cristal

    __enable_interrupt(); // habilita a CPU a aceitar requisi��es de interrup��o
}

void ini_timer0(void){
    /*  Inicializa��o do timer 0
     *
     * -> Interrup��o temporizada de 1 s
     *    CONTADOR
     *      - CLOCK:  ACLK
     *      - FDIV: 1
     *      - Modo do contador: UP
     *      - Interrup��o do contador:  desativada
     *
     *    M�DULO 0
     *      - Fun��o: compara��o
     *      - Valor para TA0CCR0 = 32767 (32768 - 1)
     *      - Int.: habilitada     *
     */
    TA0CTL = TASSEL0 + MC0;
    TA0CCTL0 = CCIE;
    TA0CCR0 = vel; // tempo do temporizador
}



#pragma vector = TIMER0_A0_VECTOR
__interrupt void RTI_do_Mod0_Timer0(void){
    /* 1 - precisa limpar flag de interrup��o?
     *     R: n�o pois o harware limpa automaticamente
     *
     *     A CPU entra nessa RTI a cada 1 segundo
     */
    if(X == BIT3){
        X = BIT0;
    }

    else{
        X = X << 1;
    }
    P1OUT = X;
}

#pragma vector = PORT2_VECTOR

__interrupt void RTI_da_porta_2(){
    // Passo 1: debouncing - desabilitar int. de P2.0 E P2.1
    P1IFG &= ~(BIT0 + BIT1);
    P1IE &= ~(BIT0 + BIT1);

    // Passo 2: iniciar temporizador
    TA1CTL |= MC0;
}

#pragma vector = TIMER1_A0_VECTOR
__interrupt void RTI_M0_Timer1(){
    // Passo 1: parar temporizador
    TA1CTL &= ~MC0;
    // Passo 2: verificar se P2.0 est� em n�vel baixo
    //      - verificar sentido de giro
    if((~P2IN) & BIT0 == BIT0){
        switch((~P2IN) & BIT1){
        case (2):
            if(vel >= 600){
                vel -= 100; // velocidade vai at� 100
                //for(i = 0; i < 10000; i++);
            }
            break;
        case (0):
            if(vel <= 15900){
                vel += 100; // vai at� 16000
                //for(i = 0; i < 10000; i++);
            }
            break;
        }
    }
    TA1CTL &= ~TAIFG;
    /*
    if((~P2IN) & (BIT0 + BIT1)){
        if(vel >= 600){
            vel -= 100; // velocidade vai at� 100
        }
    }
    else if((~P2IN) & (BIT0 + ~BIT1)){
        if(vel <= 15900){
            vel += 100; // vai at� 16000
        }
    }*/

    TA0CCR0 = vel; // seta o valor de vel para contagem
    P2IFG = 0;
    P2IE |= BIT0 + BIT1;
}



void ini_timer1_deb(){
    /*
     *  Inicializa Timer0 para debouncer
     *
     *   Temporiza��o de ~ 1ms
     *
     *   CONTADOR:
     *      -> Clock: SMCLK ~ 2 MHz
     *          - Fdiv: 1 (cabe no registrador)
     *      -> Modo: UP (inicialmente parado)
     *      -> Interup��o: desabilitada
 *
 *      M�DULO 0:
 *          -> Fun��o: compara��o (nativa)
 *          -> Interrup��o: habilitada
 *          -> Valor para TA0CCR0
 *              - TACCR0 = (0,001 * 2M) = 2000
     */
    TA1CTL = TASSEL1;
    TA1CCTL0 = CCIE;
    TA1CCR0 = 5000;
}
