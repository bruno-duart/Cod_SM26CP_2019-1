#include <msp430.h>

typedef unsigned char u_char;
typedef unsigned int u_int;
int cont, index, dt, graus;
short select = 0;
typedef struct {
    u_char r;
    u_char g;
    u_char b;
} RGBLED;
#define DATA_OUT_PIN BIT7
void sendRGB(u_char numberOfLEDs);
RGBLED data[11] = { 0, };
RGBLED cor1 = {0,0,255};
RGBLED cor2 = {255,0,0};
RGBLED cor3 = {255, 255, 0};
RGBLED aux;

void config_ini(void);
void ini_P1_P2(void);
//void ini_Timer1_Cap(void);
void ini_Timer0(void);
void sendRGB(u_char numberOfLEDs);
void mensagem1(void);
void mensagem2(void);
void mensagem3(void);

unsigned int cap_atual = 0, cap_anterior = 0;
unsigned long contagens = 4096;
unsigned char i = 0;

RGBLED amarelo={255,255,0};
RGBLED verde={0,255,0};
RGBLED vermelho={255,0,0};
RGBLED blu={0, 0, 255};
RGBLED preto={0,0,0};
unsigned int count_ciclos =0;

//-----------------------------------------------------------------------------
void main(void){
   config_ini();
    ini_P1_P2();
    //ini_Timer1_Cap();
    ini_Timer0();


    while (1) {

    }

}
//-----------------------------------------------------------------------------


#pragma vector=PORT1_VECTOR
__interrupt void RTI_P1_select(void){
    if(~P1IN & BIT3){
        if(select == 0){
            select = 1;
        }
        else if(select == 1){
            select = 2;
        }
        else{
            select = 0;
        }
    }/*
    else if(~P1IN & BIT4){
        aux.r = cor1.r;
        aux.g = cor1.g;
        aux.b = cor1.b;
        cor1.r = cor2.r;
        cor1.g = cor2.g;
        cor1.b = cor2.b;
        cor2.r = aux.r;
        cor2.g = aux.g;
        cor2.b = aux.b;
        sendRGB(11);
    }*/
    P1IFG &= ~BIT3;
}

// RTI do M0 do Timer 0
#pragma vector=TIMER0_A0_VECTOR
__interrupt void interrupcaoTimer(void){

    if(select == 0){
        mensagem1();
    }else if (select == 1){
        mensagem2();
    }else{
        mensagem3();
    }
    sendRGB(11);
}
/*
// RTI do M0 do Timer 1
#pragma vector=TIMER1_A0_VECTOR
__interrupt void Timer1A_CC0_RTI(void){

    cap_atual = TA1CCR0;

    if(i == 1){
        if(count_ciclos > 1){
            contagens = 65536 - cap_anterior + ((count_ciclos - 1)*65536) + cap_atual;
            count_ciclos = 0;

        }else{
            if(cap_atual < cap_anterior){
                contagens = (65536 - cap_anterior) + cap_atual;
            }else{
                contagens = cap_atual - cap_anterior;
            }
            count_ciclos = 0;
        }
        if(contagens < 4096) contagens = 4096;
        //else if(contagens > 65536) contagens = 65536; // professor falou pra colocar (remover??)
        TA0CCR0 = contagens >> 6; // Atualiza tempo / divide por 64
    }
    cap_anterior = cap_atual;
    i = 1;
}*/
/*
// RTI do CONTADOR do Timer 1
#pragma vector=TIMER1_A1_VECTOR
__interrupt void Timer1A_CCC_RTI(void){
      (void)TA1IV;
      count_ciclos++;

}
*/
/*
void ini_Timer1_Cap(void){
    * Clock: SMCLK ~ 2 MHz
    * - Fdiv: 8
    * - Clock: 250 kHz
    *
    * - Resol.: 4 us * 65536 ~ 262 ms
    *
    *
    *
    TA1CTL = TASSEL1 + ID0 + ID1 + MC1 + TAIE;
    TA1CCTL0 = CM0 + CAP + CCIE;
}*/

void ini_Timer0(void){
    TA0CTL = TASSEL1 + ID0 + ID1 + MC0;
    TA0CCTL0 = CCIE;
    TA0CCR0 = 2000;
}

void ini_P1_P2(void){
    P1DIR = ~(BIT3);// + BIT4);
    P1OUT = (BIT3);// + BIT4);
    P1REN = (BIT3);// + BIT4);
    P1IES = (BIT3);// + BIT4);
    P1IFG &= ~(BIT3);// + BIT4);
    P1IE = (BIT3);// + BIT4);
    P1SEL |= DATA_OUT_PIN;
    P1SEL2 |= DATA_OUT_PIN;

    P2DIR = ~BIT0;
    P2OUT = 0;
    P2SEL |= BIT0;

    UCB0CTL0 |= UCCKPH + UCMSB + UCMST + UCSYNC;
    UCB0CTL1 |= UCSSEL_2;
    UCB0BR0 |= 0x03;
    UCB0BR1 = 0;
    UCB0CTL1 &= ~UCSWRST;
}

void config_ini(void){

    WDTCTL = WDTPW | WDTHOLD;
    DCOCTL = CALDCO_16MHZ;
    BCSCTL1 = CALBC1_16MHZ;


    __enable_interrupt();
}


void sendRGB(u_char numberOfLEDs) {
    u_int c = 0;
    u_char led = 0;
    u_char leds[3];
    u_char d;



    while (c < numberOfLEDs) {
        leds[0] = data[c].g;
        leds[1] = data[c].r;
        leds[2] = data[c].b;
        while (led < 3) {
            u_char b = 0;
            d = leds[led];
            while (b < 8) {
                while (!(IFG2 & UCB0TXIFG));
                (d & 0x80) ? (UCB0TXBUF = 0xF0) : (UCB0TXBUF = 0xC0);
                d <<= 1;
                b++;
            }
            led++;
        }
        led = 0;
        c++;
    }
    __enable_interrupt();

}

void mensagem1(void){
    if(graus==0 || graus==1 || graus == 5 || graus == 6 || graus == 11 || graus == 12 || graus == 13 || graus == 18 || graus == 19 || graus == 27 || graus == 28 || graus == 36 || graus == 37){
        for(cont=0; cont<11; cont++){
            if(cont>=0 && cont < 3 )
                data[cont]=blu;
            else
                data[cont]=amarelo;
        }
    }
    else if(graus>=2 && graus<=4){
        for(cont=0; cont<11; cont++){
            if(cont==5 || cont==4 || cont==3)
                data[cont]=amarelo;
            else
                data[cont]=blu;
        }
    }
    else if((graus >= 9 && graus <= 10) ||(graus == 14 || graus == 15) || (graus >= 23 && graus <= 24)){
        for(cont=0; cont<11; cont++){
            if(cont==9 || cont == 10)
                data[cont]=amarelo;
            else
                data[cont]=blu;
        }
    }
    else if(graus == 20 || graus == 21 || graus == 22){// || graus == 26 || (graus >= 19 && graus <= 21)){
        for(cont=0; cont<11; cont++){
            if(cont==9 || cont == 10 || cont == 6 || cont == 7)
                data[cont]=amarelo;
            else
                data[cont]=blu;
        }
    }
    else if(graus == 29 || graus == 30 || graus == 31 || graus == 38){
        for(cont = 0; cont < 11; cont++){
            if(cont == 10 || cont == 9 || cont == 6){
                data[cont] = amarelo;
            }
            else
                data[cont] = blu;
        }
    }
    else if (graus ==  32 || graus == 33){
        for(cont=0; cont<11; cont++){
            if(cont == 10 || cont==9 || cont == 8 || cont == 7 || cont == 6)
                data[cont]=amarelo;
            else
                data[cont]=blu;
        }
    }
    else if(graus == 39){
        for(cont=0; cont<11; cont++){
            if(cont == 10 || cont==9 || cont == 6 || cont == 5)
                data[cont]=amarelo;
            else
                data[cont]=blu;
        }
    }
    else if(graus == 40){
        for(cont=0; cont<11; cont++){
            if(cont == 10 || cont==9 || cont == 6 || cont == 5 || cont == 4)
                data[cont]=amarelo;
            else
                data[cont]=blu;
        }
    }
    else if(graus == 41){
        for(cont=0; cont<11; cont++){
            if(cont == 10 || cont==9 || cont == 8 || cont == 7 || cont == 6 || cont == 4 || cont == 3)
                data[cont]=amarelo;
            else
                data[cont]=blu;
        }
    }
    else if(graus == 42){
        for(cont=0; cont<11; cont++){
            if(cont == 10 || cont==9 || cont == 8 || cont == 7 || cont == 6 || cont == 3)
                data[cont]=amarelo;
            else
                data[cont]=blu;
        }
    }
    else{
        for(cont=0; cont<11; cont++){
            data[cont]=blu;
        }
    }
    graus++;
    if (graus == 64){
        graus = 0;
    }

}

void mensagem2(void){
        if(graus == 0 || graus == 5 || graus == 9){
            for(cont = 0; cont < 11; cont++){
                if(cont >=3 && cont <= 7)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 1 || graus == 2 || graus == 13){
            for(cont = 0; cont < 11; cont++){
                if(cont == 3 || cont == 5 || cont == 7)
                    data[cont] = cor1;
                else
                   data[cont] = cor2;
            }
        }
        else if(graus == 3 || graus == 12){
                for(cont = 0; cont < 11; cont++){
                    if(cont == 3 || cont == 7)
                        data[cont] = cor1;
                    else
                       data[cont] = cor2;
            }
        }
        else if(graus == 6){
            for(cont = 0; cont < 11; cont++){
                if(cont == 6)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 7){
            for(cont = 0; cont < 11; cont++){
                if(cont == 5)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 8){
            for(cont = 0; cont < 11; cont++){
                if(cont == 4)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 11){
            for(cont = 0; cont < 11; cont++){
                if(cont == 4 || cont == 5 || cont == 6)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 14){
            for(cont = 0; cont < 11; cont++){
               if(cont == 7 || cont == 5 || cont == 4)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 16){
            for(cont = 0; cont < 11; cont++){
                if(cont == 4 || cont == 5 || cont == 6)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 17 || graus == 18 || graus == 19){
            for(cont = 0; cont < 11; cont++){
                if(cont == 3 || cont == 7)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 21){
             for(cont = 0; cont < 11; cont++){
                if(cont >= 3 && cont <= 7)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 22 || graus == 23){
            for(cont = 0; cont < 11; cont++){
                if(cont == 7 || cont == 5)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else if(graus == 24){
            for(cont = 0; cont < 11; cont++){
                if(cont == 6)
                    data[cont] = cor1;
                else
                    data[cont] = cor2;
            }
        }
        else{
            for(cont = 0; cont < 11; cont++)
                data[cont] = cor2;
        }
        graus++;
        if (graus == 64)
            graus = 0;
}
void mensagem3(void){
    if(graus == 0 || graus == 1 || graus == 5 || graus == 6 || graus == 9 || graus == 10 || graus == 13 || graus == 14 || graus == 21 || graus == 22 || graus == 29 || graus == 30 || graus == 34 || graus == 35)
        for(cont = 0; cont < 11; cont++)
            if(cont <11 && cont >= 3)
                data[cont] = cor2;
            else
                data[cont] = cor1;
    else if(graus == 2 || graus == 5)
        for(cont = 0; cont < 11; cont++)
            if(cont == 9 || cont == 8)
                data[cont] = cor2;
            else
                data[cont] = cor1;
    else if(graus == 4 || graus == 3)
        for(cont = 0; cont < 11; cont++)
            if(cont == 7 || cont == 8)
                data[cont] = cor2;
            else
                data[cont] = cor1;
    else if(graus == 15 || graus == 16 || graus == 17 || graus == 18)
        for(cont = 0; cont < 11; cont++)
            if(cont == 3 || cont == 4 || cont == 9 || cont == 10)
                data[cont] = cor2;
            else
                data[cont] = cor1;
    else if(graus == 15 || graus == 16 || graus == 17 || graus == 18  || graus == 31  || graus == 32  || graus == 33 )
        for(cont = 0; cont < 11; cont++)
            if(cont == 3 || cont == 4 || cont == 9 || cont == 10)
                data[cont] = cor2;
            else
                data[cont] = cor1;
    else if(graus == 23 )
        for(cont = 0; cont < 11; cont++)
            if(cont == 6 || cont == 7 || cont == 9 || cont == 10)
                data[cont] = cor2;
            else
                data[cont] = cor1;
    else if(graus == 24 )
        for(cont = 0; cont < 11; cont++)
            if(cont == 6 || cont == 7 || cont == 9 || cont == 10 || cont == 5)
                data[cont] = cor2;
            else
                data[cont] = cor1;
    else if(graus == 25 )
        for(cont = 0; cont < 11; cont++)
            if(cont == 4 || cont == 5 || cont == 7 || cont == 8|| cont == 9 || cont == 10)
                data[cont] = cor2;
            else
                data[cont] = cor1;
    else if(graus == 26 )
        for(cont = 0; cont < 11; cont++)
            if(cont == 4 || cont == 3 || cont == 7 || cont == 9 || cont == 8)
                data[cont] = cor2;
            else
                data[cont] = cor1;
    else
        for(cont = 0; cont < 11; cont++)
            data[cont] = cor1;
    graus++;
    if (graus == 64)
        graus = 0;
}
