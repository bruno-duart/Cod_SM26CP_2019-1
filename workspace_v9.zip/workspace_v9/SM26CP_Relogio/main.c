#include <msp430.h> 

void ini_P1_P2(void);
void ini_uCon(void);
void ini_TA0(void);

short hora=0, min=0, seg=0;

void main(void)
{
    ini_uCon();
    ini_TA0();
    ini_P1_P2();
	do{


	}while(1);
}

void ini_uCon(void){
    WDTCTL = WDTPW | WDTHOLD;

    DCOCTL = CALDCO_16MHZ;
    BCSCTL1 = CALBC1_16MHZ;
    BCSCTL2 = DIVS0 + DIVS1;
    BCSCTL3 = XCAP0 + XCAP1;

    while(BCSCTL3 & LFXT1OF);

    __enable_interrupt();
}

#pragma vector=TIMER0_A0_VECTOR
__interrupt void RTI_CLOCK(void){
    if(seg == 59){
        seg = 0;
        min++;
    } else{
        seg++;
        P1OUT ^= BIT6;
    }
    if(min > 59){
        min = 0;
        hora++;
    }
    if(hora > 23){
        hora = 0;
    }
}

#pragma vector=PORT1_VECTOR
__interrupt void RTI_P1(void){
    P1IFG = 0;
    TA0CCTL0 ^= CCIE;

}

void ini_TA0(void){
    // TAclk = ACLK = 32768 Hz, Modo UP, Interrup. a cada 1s
    TA0CTL = TASSEL0 + MC0;
    //TA0CCTL0 = CCIE;
    TA0CCR0 = 32767;
}

void ini_P1_P2(void){
    P1DIR = ~BIT3;
    P1OUT = BIT3;
    P1IFG = 0;
    P1IE = BIT3;
    P1IES = BIT3;
    P1REN = BIT3;
    P2DIR = 0xFF;
    P2OUT = 0;
}
