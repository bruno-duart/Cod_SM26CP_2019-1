/* Timer A: Exemplo de s�ntese de sinal senoidal via PWM
 *
 *   >>> Caracter�sticas:
 *          - freq. sinal: 100 Hz
 *          - Timer1
 *          - Resolu��o do sinal: 32 ciclos PWM / ciclo senoide
 *
 *   >>> Configura��es:
 *          - Timer1: gera��o de PWM via M�dulo 1
 *              -> Clock: SMCLK
 *              -> C�lculos:
 *                      - freq. PWM = 100 * 32 = 3200 Hz
 *                      - Para ajuste da RC de 1 em 1%, o valor de
 *                        TA1CCR1 deve ser de:
 *                         t_pwm = 1/3200 .:. t_clk = 1 / f_clk
 *                         t_clk = (1/3200)/100 = 1/32000 = 3,125 us
 *                         f_clk = 320 kHz
 *
 *                         Se f_clk = 2 MHz, ent�o a resolu��o ser�:
 *                              f_clk = f_pwm * res .:. f_clck/f_pwm
 *
 *                              res = 2M/3200 = 625 contagens
 *
 *                              res_% = 3200/2M = 0,16 %
 *
 * */

#include <msp430.h> 


void ini_uCon(void);
void ini_P1_P2();
void ini_Timer1_PWM();

void main(void)
{
	ini_uCon();
	ini_P1_P2();
	ini_Timer1_PWM();

	while(1){

	}
}

void ini_uCon(void){
    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer

    /* Configura��o do Sistema B�sico de Clock BCS
    *
    * -> Osciladores:
    *      LFXT1CLK = 32 768 Hz
    *      VLO = N�o utilizado
    *      DCO ~ 16 MHz (via dados de calibra��o do fabricante)
    * ->Sa�das de CLK
    *      ACLK = LFXT1CLK = 32 768 Hz
    *      MCLK = DCOCLK ~ 16 MHz
    *      SMCLK = DCOCLK/8 ~ 2 MHz
    *
    * */
    DCOCTL = CALDCO_16MHZ;
    BCSCTL1 = CALBC1_16MHZ;
    BCSCTL2 = DIVS0 + DIVS1;
    BCSCTL3 = XCAP0 + XCAP1;

    while(BCSCTL3 & LFXT1OF);

    __enable_interrupt();
}


void ini_P1_P2(){
    /* Porta 1:
     *      -> P1.0 - LED_VM - sa�da em n�vel baixo
     *      -> P1.6 - LED_VD - sa�da em n�vel baixo
     *      -> P1.x - N.C. - sa�da em n�vel baixo
     *
     * Porta 2:
     *      -> P2.1 - TA1.1
     *      -> P2.2 - TA1.1
     *      Mudar fun��o dos pinos 9 e 10
     *          *Op��o de aula de sair com o mesmo sinal nos pinos 9 e 10
     *      -> P2.x - N.C. - sa�da em n�vel baixo
     *      -> Pinos 18 e 19 com fun��es nativas XIN e XOUT
     *
     * */
    P1DIR = 0xFF;
    P1OUT = 0;

    P2DIR = 0xFF;
    P2OUT = 0;
    P2SEL |= BIT1 + BIT2;

}

void ini_Timer1_PWM(){
    /* Inicializa��o do Timer 1 para gerar PWM
     *
     * Freq.: 3200 Hz
     *
     * Contador:
     *      - Clock: SMCLK - 2 MHz
     *          - Fdiv = 1
     *      - Modo: UP
     *      - Interrup��o desabilitada
     *
     * M�dulo 0: per�odo do PWM
     *      - Fun��o: compara��o nativa
     *      - Interrup��o desabilitada
     *      - Valor para TA1CCR0
     *              - 2M / 3200 - 1 = 624
     *
     *
     * M�dulo 1: gera o PWM / ajuste duty-cycle
     *      - Fun��o: compara��o (nativa)
     *      - Modo sa�da: 7 (Reset/Set)
     *      - TA1CCR1: Vai depneder da amplituda da senoide
     *        e, portanto, deve ser atualizado ciclo-a-ciclo
     *      - Int.: Habilitada!!!
     *
     *      TA1CTL = TASSEL1 + MC0;
     *      TA1CCTL1 = OUTMOD0 + OUTMOD1 + OUTMOD2 + OUT + CCIE;
     *
     *
     *
     * */
    TA1CTL = TASSEL1 + MC0;
    TA1CCTL1 = OUTMOD0 + OUTMOD1 + OUTMOD2 + OUT + CCIE;

}

#pragma vector=TIMER1_A1_VECTOR
__interrupt void RTI_M1_TA1(){

    /* Esta � a RTI dos M�dulos 1, 2 e contador.4
     * Portanto, a flage de interrup��o n�o � limpa automaticamente
     * pelo hardware! Dessa forma, precisamos limpar a flag do M�dulo1
     * que pode ser feita via vetor de int. TA1lv j� limpa as flags. Portanto
     * peode-se fazer isso da seugirna*/

    TA

    TA1CCR = pwm_vetor[i];
    if(i >= 31){
        i = 0;
    }
    else
        i++;
}
