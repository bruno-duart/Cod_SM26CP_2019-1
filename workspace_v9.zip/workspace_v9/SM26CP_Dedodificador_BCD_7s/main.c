#include <msp430.h> 

#define     seg_a       BIT0
#define     seg_b       BIT1
#define     seg_c       BIT2
#define     seg_d       BIT3
#define     seg_e       BIT4
#define     seg_f       BIT5
#define     seg_g       BIT6
#define     seg_p       BIT7

#define     ZERO        (seg_a + seg_b + seg_c + seg_d + seg_e + seg_f)
#define     UM          (seg_b + seg_c)
#define     DOIS        (seg_a + seg_b + seg_d + seg_e + seg_g)
#define     TRES        (seg_a + seg_b + seg_c + seg_d + seg_g)
#define     QUATRO      (seg_b + seg_c + seg_f + seg_g)
#define     CINCO       (seg_a + seg_c + seg_d + seg_f + seg_g)
#define     SEIS        (seg_a + seg_c + seg_d + seg_e + seg_f + seg_g)
#define     SETE        (seg_a + seg_b + seg_c)


void ini_P1_P2(void);


void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
	ini_P1_P2();

	do{
	    /*
	     * 1 - Leitura das Chaves - P1IN
	     *   P1DIR - Dire��o dos pinos da P1
	     *
	     * bit                  7 6 5 4   3 2 1 0
         * P1IN                 X X X X   X Y Y Y
         * (BIT0 + BIT1 + BIT2) 0 0 0 0   0 1 1 1
	     *     AND bit-bit     ---------------------
	     *                      0 0 0 0   0 Y Y Y
	     * */

	    switch(P1IN & (BIT0 + BIT1 + BIT2)){
	        case 0:
                P2OUT = ZERO;
                break;
	        case 1:
                P2OUT = UM;
                break;
	        case 2:
                P2OUT = DOIS;
                break;
	        case 3:
                P2OUT = TRES;
                break;
	        case 4:
                P2OUT = QUATRO;
                break;
	        case 5:
                P2OUT = CINCO;
                break;
	        case 6:
                P2OUT = SEIS;
                break;
	        case 7:
                P2OUT = SETE;
                break;
	    }
	}while(1);
}

void ini_P1_P2(void){
    /*Inicializa��o da P1
     *          P1.0~P1.2: entradas com resistor de pull-down
     *          P1.3~P1.7: n.c. - Sa�das em nivel baixo
     *
     *
     *           P1DIR - Dire��o dos pinos da P1
     *
     *                  bit     7 6 5 4   3 2 1 0
     *                  ini     0 0 0 0   0 0 0 0
     *                  des     1 1 1 1   1 0 0 0
     *                       ---------------------
     *                      0x      F         8
     *           P1DIR = 0xF8; ou P1DIR = (BIT7 + BIT6 + BIT5 + BIT4 + BIT3);
     *           P1OUT = 0x0;
     *
     *           ligar resistores nas entradas
     *
     *           P1REN - Habilita resistor no pino da p1
     *
     *                  bit     7 6 5 4   3 2 1 0
     *                  ini     0 0 0 0   0 0 0 0
     *                  des     0 0 0 0   0 1 1 1
     *                       ---------------------
     *                  hex 0x         0        7
     *           P1REN = 0x07;
     *
     *           limpar bits de P1OUT garantindo resistores de pull-down e sa�das em n�vel baix
     *           P1OUT = 0x0;
     *                  bit     7 6 5 4   3 2 1 0
     *                  ini     0 0 0 0   0 0 0 0
     *                  des     0 0 0 0   0 0 0 0
     *                       ---------------------
     *                  hex 0x        0         0
     * */

    P1DIR = 0xF8;
    P1REN = 0x07;
    P1OUT = 0;

    /*Inicializa��o da P2
     *
     *      P2.0~P2.07: display apagado - sa�das n�vel baixo
     *          -> Deve-se mudar as fun��es dos pinos 18 e 19 para P2.6 e P2.7
     *
     *      P2DIR - Dire��o dos pinos da P1
     *
     *                  bit     7 6 5 4   3 2 1 0
     *                  ini     0 0 0 0   0 0 0 0
     *                  des     1 1 1 1   1 1 1 1
     *                       ---------------------
     *                      0x      F        F
     *           P2DIR = 0xFF;
     *      P2OUT - Ajusta n�vel de sa�da da P2
     *                  bit     7 6 5 4   3 2 1 0
     *                  ini     0 0 0 0   0 0 0 0
     *                  des     0 0 0 0   0 0 0 0
     *                       ---------------------
     *                      0x     0         0
     *
     *      P2SEL - Muda fun��o dos pinos 18 e 19.
     *                  bit     7 6 5 4   3 2 1 0
     *                  ini     1 1 0 0   0 0 0 0
     *                  des     0 0 0 0   0 0 0 0
     *                       ---------------------
     *                      0x      0       0
     *                  P2SEL = 0; ou
     *                  P2SEL &= ~(BIT6 + BIT7);
     *
     *
     * */
    P2DIR = 0xFF;
    P2OUT = 0;
    P2SEL &= ~(BIT6 + BIT7);
}
