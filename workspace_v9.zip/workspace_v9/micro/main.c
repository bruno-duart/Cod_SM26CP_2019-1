#include <msp430g2553.h>
typedef unsigned char u_char;
typedef unsigned int u_int;
int cont, index, dt;
typedef struct {
    u_char r;
    u_char g;
    u_char b;
} RGBLED;
#define DATA_OUT_PIN BIT7
void sendRGB(u_char numberOfLEDs);
RGBLED data[10] = { 0, };

//##################### CONFIGURACOES INICIAIS DE PORTA E CLOCK #####################
void init(){
    WDTCTL = WDTPW + WDTHOLD;
    BCSCTL1 = CALBC1_16MHZ;
    DCOCTL = CALDCO_1MHZ;
    P1SEL |= DATA_OUT_PIN;
    P1SEL2 |= DATA_OUT_PIN;
    P1DIR = ~BIT6;
    P1OUT = BIT6;
    P1REN = BIT6;
    P1IFG = 0;
    P1IE = BIT6;
    P1IES = BIT6;
    UCB0CTL0 |= UCCKPH + UCMSB + UCMST + UCSYNC; // 3-pin, 8-bit SPI master
    UCB0CTL1 |= UCSSEL_2; // SMCLK
    UCB0BR0 |= 0x03; // 1:3 - 16MHz/3 = 0.1875us
    UCB0BR1 = 0;
    UCB0CTL1 &= ~UCSWRST;
}

//############################# INICIALIZACAO DO TIMER ##############################
void ini_TimerA(void){
    TAR = TACLR;
    TA0CTL = TASSEL1 + MC0;
    TA0CCTL0 = CCIE;
    TA0CCR0 = 100;

}


//############### INTERRUPCAO GERADA PELO SENSOR OPTICO ##############################
#pragma vector=PORT1_VECTOR
__interrupt void interrupcaoSensor(void){
    TA0CTL &= ~MC0;
    TA0CCR0 = TAR / 72;
    TAR = 0x0;
    P1IFG = 0x00;
    TA0CTL |= MC0;
}

//############### INTERRUPCAO GERADA PARA MUDAR AS indexES DA FITA DE LED ##############
#pragma vector=TIMER0_A0_VECTOR
__interrupt void interrupcaoTimer(void){
    for(cont=0; cont<10; cont++){
        if(index>=0 && index<=35){
            data[cont].r = 255;
            data[cont].g = 0;
            data[cont].b = 0;
        }
        if(index>=36 && index<=72){
            data[cont].r = 0;
            data[cont].g = 255;
            data[cont].b = 0;
        }
    }
    sendRGB(10);
    index++;
    if(index==73)
        index=0;
}
//############ MANDA A INFORMACAO DO VETOR DATA[] PARA A FITA DE LED ################
void sendRGB(u_char numberOfLEDs) {
    u_int c = 0;
    u_char led = 0;
    u_char leds[3];
    u_char d;
    while (c < numberOfLEDs) {
        leds[0] = data[c].g;
        leds[1] = data[c].r;
        leds[2] = data[c].b;
        while (led < 3) {
            u_char b = 0;
            d = leds[led];
            while (b < 8) {
                while (!(IFG2 & UCB0TXIFG));
                (d & 0x80) ? (UCB0TXBUF = 0xF0) : (UCB0TXBUF = 0xC0);
                d <<= 1;
                b++;
            }
            led++;
        }
        led = 0;
        c++;
    }
    __delay_cycles(800); // delay 50us to latch data, may not be necessary
}

void main(void) {
    init();
    ini_TimerA();
    index=0;
    __enable_interrupt();
    while (1);
}
