#include <msp430.h> 


/**
 * main.c
 */
int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
	return 0;
}

void ini_uCon(void){
    WDTCTL = WDTPW | WDTHOLD;                                                   //PARANDO O WDT

    DCOCTL = CALDCO_16MHZ;                                                      //MCLK = 16MHZ --> FREQUENCIA PR� CALIBRADA
    BCSCTL1 = CALBC1_16MHZ;                                                     //ACLK = 32768HZ (LFXT1) --> CRISTAL
    BCSCTL2 = DIVS0;                                                    //SCLK = 2MHZ --> FATOR DE DIVISAO 8
    BCSCTL3 = XCAP0 + XCAP1;                                                    //C = 12pF --> CAPACITORES PARA O LFXT1

    while(BCSCTL3 & LFXT1OF);                                                   //SAI DO LOOP PARA LFXT1 EST�VEL

    __enable_interrupt();                                                       //HABILITA A GERA��O DE INTERRUP��ES
}

void config_UART(void){
    UCA0CTL1 |= UCSWRST;
    UCA0CTL0 = 0;
    UCA0CTL1 = UCSSEL1 + UCSWRST; // Fonte clock: SMCLK ~ 8 MHz
    UCA0BR0 = 0x41; // Para 9600 bps, conforme Tabela 15-4 do User Guide
    UCA0BR1 = 0x03;
    UCA0MCTL = UCBRS1;
    UCA0CTL1 &= ~UCSWRST; // Coloca a interface no modo normal
    IFG2 &= ~UCA0TXIFG; // Limpa TXIFG, pois o bit � setado ap�s reset
    IE2 |= UCA0TXIE + UCA0RXIE; // Habilitando a gera��o de int. para RX e TX
}

void ini_ADC10(void){
    ADC10CTL0 =
}

