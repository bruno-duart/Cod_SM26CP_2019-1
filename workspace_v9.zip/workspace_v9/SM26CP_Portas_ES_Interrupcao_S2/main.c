#include <msp430.h> 

#define LED_VM BIT0
#define LED_VD BIT6

void ini_P1_P2();

char pisca = 0;

void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer

	__enable_interrupt(); // Instru��o para que a CPU aceite requisi��es de interrup��o
	ini_P1_P2();
	unsigned long i;
	do{
	    if(pisca > 0){
	        P1OUT ^= LED_VD;
	        for(i=0; i<100000; i++);

	    }
	}while(1);
}

#pragma vector = PORT1_VECTOR

__interrupt void RTI_da_Porta_1(){
    // Passo 1: Limpar a flag de interrup��o de P1.3 (obrigat�rio).
    // Como somente o BIT3 pode solicitar interrup��o, n�o h� necessidade de verificar qual bit solicitou interrup��o
    // Ver linha ?
    P1IFG &= ~BIT3;

    if(pisca > 0){
        pisca = 0;          //Desliga
        P1OUT &= ~LED_VM;   //Apaga vermelho
        P1OUT &= ~LED_VD;   //Apaga verde
    } else{
        pisca = 1;          //Liga
        P1OUT |= LED_VM;    //Acende LED_VM
    }
}

//------------------------------------------
void ini_P1_P2(){
    /*Inicializa��o da Porta 1
     *
     * P1.3 : S2 - Entrada, resistor interno de pull,up
     *             com interrup��o habilitada por borda de descida
     *      Vcc
     *      ---
     *       |
     *       -
     *      | |     Res. Pull-up
     *      | |
     *       -
     *       |
     *     -------> P1.3
     *    |  |
     *    |  |
     *    _  |
     *  C _  |
     *    |   \S2
     *    |__|
     *      |
     *     ---
     *      -
     *
     *     P1.0 - Led Vermelho - sa�da em n�vel baixo
     *     P1.6 - Led Verde - sa�da em n�vel baixo (conectar jumper)
     *     P1.X - N.C - Sa�da em n�vel baixo
     *
     *     P1DIR = ~BIT3;
     *
     *     P1REN = BIT3; Setar o bit3 para conectar o resistor em P1.3
     *
     *     P1OUT = BIT3; //Todas as sa�das n�vel baixo e
     *                   // Resistor de P1.3 com fun��o Pull-up
     *     P1IES - Seleciona a borda de interrup��o. Zero para detectar borda de subida. Um para detectar borda de descida.
     *     P1IES = BIT3;
     *
     *     P1IFG - Flags de interrup��o de P1
     *                      � necess�rio limpar as flags de interrup��o antes de habilitar qualquer
     *                      interrup��o.
     *     P1IFG = 0;
     *
     *     P1IE - Habilita a gera��o de interrup��o pelas entradas de P1 (somente para a interrup��o de interesse)
     *     P1IE = BIT3;
     * */
    P1DIR = ~BIT3;
    P1REN = BIT3;
    P1OUT = BIT3;
    P1IES = BIT3;
    P1IFG = 0;
    P1IE = BIT3;
    /*  Inicializa��o da Porta 2
     *
     *  P2.X - N.C - sa�das em n�vel baixo
     *  Pinos 18 e 19: N.C - sa�da em n�vel baixo (mudar a fun��o)
     *
     *  - Para mudar fun��o dos pinos 18 e 19, deve-se limpar os bits 6 e 7 do registrador
     *  P2SEL;
     *
     *  P2SEL = 0; ou P2SEL &= ~(BIT6 + BIT7); ou P2SEL = 0;
     *
     *  P2DIR = 0xFF; //Todos os bits em 1, garantindo que sejam sa�das
     *  P2OUT = 0;  /Sa�das n�o conectadas, em n�vel baixo.
     *
     *
     *
     *
     * */
     P2SEL &= ~(BIT6 + BIT7);
     P2DIR = 0xFF;
     P2OUT = 0;

}
