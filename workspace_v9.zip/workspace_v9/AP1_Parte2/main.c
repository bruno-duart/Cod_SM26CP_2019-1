#include <msp430.h>

#define     ZERO    (BIT0 + BIT1 + BIT2 + BIT3 + BIT4 + BIT5)
#define     UM      (BIT1 + BIT2)
#define     DOIS    (BIT0 + BIT1 + BIT3 + BIT4 + BIT6)
#define     TRES    (BIT0 + BIT1 + BIT2 + BIT3 + BIT6)
#define     QUATRO  (BIT1 + BIT2 + BIT5 + BIT6)
#define     CINCO   (BIT0 + BIT2 + BIT3 + BIT5 + BIT6)
#define     SEIS    (BIT0 + BIT2 + BIT3 + BIT4 + BIT5 + BIT6)
#define     SETE    (BIT0 + BIT1 + BIT2)
#define     OITO    255
#define     NOVE    ~BIT4

void ini_P1_P2();
void wait();

int l = 0;
int i;
short contagem = 0;

void main(void) {

    ini_P1_P2();
    short unidade, dezena;

    while(1){
        unidade = contagem % 10;
        dezena = contagem / 10;
        P1OUT |= BIT1;
        switch(unidade){
             case 0:
                 P2OUT = ZERO;
             break;
             case 1:
                 P2OUT = UM;
             break;
             case 2:
                 P2OUT = DOIS;
             break;
             case 3:
                 P2OUT = TRES;
             break;
             case 4:
                 P2OUT = QUATRO;
             break;
             case 5:
                 P2OUT = CINCO;
             break;
             case 6:
                 P2OUT = SEIS;
             break;
             case 7:
                 P2OUT = SETE;
             break;
             case 8:
                 P2OUT = OITO;
             break;
             case 9:
                 P2OUT = NOVE;
             break;

             default:
                P2OUT = BIT7;
                contagem = 0;
             break;
         }
        wait();
        swicth_display();

        switch(dezena){
             case 0:
                 P2OUT = ZERO;
             break;
             case 1:
                 P2OUT = UM;
             break;
             case 2:
                 P2OUT = DOIS;
             break;
             case 3:
                 P2OUT = TRES;
             break;
             case 4:
                 P2OUT = QUATRO;
             break;
             case 5:
                 P2OUT = CINCO;
             break;
             case 6:
                 P2OUT = SEIS;
             break;
             case 7:
                 P2OUT = SETE;
             break;
             case 8:
                P2OUT = OITO;
            break;
            case 9:
                P2OUT = NOVE;
            break;

             default:
                P2OUT = BIT7;
             break;
         }
         wait();
         P1OUT &= ~BIT0;
    }
}

void swicth_display(){
    P1OUT &= ~BIT1;
    P1OUT |= BIT0;
}

void wait(){
    for(l = 0; l < 800; l++);
}


void ini_P1_P2(){
        WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer
        __enable_interrupt();

        P2DIR = 0xFF;  // Todos os bits da P2 como saida
        P2OUT = ZERO;  // Leds apagados
        P2SEL &= ~(BIT6 + BIT7);
        P2SEL2 = 0;

        P1DIR = ~(BIT3 + BIT4);// + BIT4);//BIT0 + BIT1;
        P1REN = BIT3 + BIT4;
        P1OUT = (BIT3 + BIT4);
        P1IE = BIT3 + BIT4;
        P1IFG = 0;
        P1IES = BIT3 + BIT4;
}

#pragma vector = PORT1_VECTOR
__interrupt void portaUm(void){
    if(P1IFG & BIT3){
        contagem++;
    }
    if(contagem == 100)
            contagem = 0;
    if(P1IFG & BIT4){
        contagem=0;
    }
    P1IFG=0;
    for(i=0; i<650; i++);
}
