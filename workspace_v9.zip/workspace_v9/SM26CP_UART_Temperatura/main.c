#include <msp430.h> 

unsigned char TX_DATA[32];
unsigned char RX_DATA[32];
unsigned char tx_index = 0, rx_index = 0;
double temperatura = 16.3;

void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer
	
	while(1);

}

//------------------------------------------------------------
#pragma vector=USCIAB0TX_VECTOR
__interrupt void RTI_TXD(void){
    IFG2 &= ~UCA0TXIFG;

    if( TX_DATA[tx_index] == '\0' ){
        tx_index = 0;
    }else{
        if(tx_index >= 32){
            tx_index = 0;
        }else{
            UCA0TXBUF = TX_DATA[tx_index];
            tx_index++;
        }
    }
}
#pragma vector=TIMER1_A0_VECTOR
__interrupt void RTI_TIMER_1_M0(void){
    TA1CTL &= ~MC0; // Para contador do Timer 1

    if( (~P1IN) & BIT3 ){
        IFG2 |= UCA0TXIFG; // Iniciar a TX pela RTI de TX
    }

    P1IFG = 0;
    P1IE |= BIT3;
}

void config_UART(void){
    UCA0CTL1 |= UCSWRST;
    UCA0CTL0 = 0;
    UCA0CTL1 = UCSSEL1 + UCSWRST; // Fonte clock: SMCLK ~ 8 MHz

    UCA0BR0 = 0x41; // Para 9600 bps, conforme Tabela 15-4 do User Guide
    UCA0BR1 = 0x03;

    UCA0MCTL = UCBRS1;

    P1SEL |= BIT1 + BIT2;
    P1SEL2 |= BIT1 + BIT2;

    UCA0CTL1 &= ~UCSWRST; // Coloca a interface no modo normal

    IFG2 &= ~UCA0TXIFG; // Limpa TXIFG, pois o bit � setado ap�s reset

    IE2 |= UCA0TXIE + UCA0RXIE; // Habilitando a gera��o de int. para RX e TX
}



