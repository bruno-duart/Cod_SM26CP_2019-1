#include <msp430.h>

//Declara��o das fun��es e vari�veis globais
//---------------------------------------------------------------------------------------------------------------------------

void ini_uCon(void);
void ini_P1_P2(void);
void ini_Timers(void);
int selecao = 0;

//Fun��o principal
//---------------------------------------------------------------------------------------------------------------------------

void main(void){


    ini_uCon();
    ini_P1_P2();
    ini_Timers();

    do{

    }while(1);

}

//Fun��es de inicializa��o
//---------------------------------------------------------------------------------------------------------------------------

void ini_uCon(void){

    WDTCTL = WDTPW | WDTHOLD;
     //MCLK = 16MHz
     //SMCLK = 8MHz
     //ACLK = 32.768Hz

     DCOCTL = CALDCO_16MHZ;
     BCSCTL1 = CALBC1_16MHZ;
     BCSCTL2 = DIVS0 + DIVS1;
     BCSCTL3 = XCAP0 + XCAP1;

     while(BCSCTL3 & LFXT1OF);

     __enable_interrupt();

}

void ini_P1_P2(void){

    P1DIR = ~(BIT0 + BIT1 + BIT3);
    P1REN = BIT0 + BIT1 + BIT3;
    P1OUT = BIT0 + BIT1 + BIT3;
    P1IES = BIT0 + BIT3;
    P1IFG = 0;
    P1IE = BIT0 + BIT3;


    P2DIR = 0xFF;
    P2OUT = 0x00;

    P2SEL |= BIT1 + BIT4;

}

void ini_Timers(void){

    TA0CTL = TASSEL1;
    TA0CCTL0 = CCIE;
    TA0CCR0 = 4999;

    TA1CTL = TASSEL1 + MC0;
    TA1CCTL1 = OUTMOD0 + OUTMOD1 + OUTMOD2 + OUT;
    TA1CCTL2 = OUTMOD0 + OUTMOD1 + OUTMOD2 + OUT;
    TA1CCR0 = 800;
    TA1CCR1 = 40;
    TA1CCR2 = 40;

}

//Rotinas de tratamento de interrup��es
//---------------------------------------------------------------------------------------------------------------------------

#pragma vector=PORT1_VECTOR
__interrupt void P1_RTI(void){

    TA0CTL |= MC0;

    P1IE &= ~(BIT1 + BIT3);

}

#pragma vector=TIMER0_A0_VECTOR
__interrupt void RTI_M0_do_Timer0(void){

    TA0CTL &= ~MC0;


    switch(~P1IN & (BIT0+BIT1)){
    case BIT0:
    case BIT1:
            if(selecao == 0){
                if(TA1CCR1 < 760){
                    TA1CCR1 += 40;
                }else{TA1CCR1 = 760;}
            }else if(selecao == 1){
                if(TA1CCR2 < 760){
                    TA1CCR2 += 40;
                }else{TA1CCR2 = 40;}
            }
    break;
    case BIT0+BIT1:
    case 0:
        if(selecao == 0){
            if(TA1CCR1 > 40){
                TA1CCR1 -= 40;
            }else{TA1CCR1 = 40;}
            }else if(selecao == 1){
                if(TA1CCR2 > 40){
                    TA1CCR2 -= 40;
                }else{TA1CCR2 = 40;}
            }
    break;
    }
    if((~P1IN) & BIT3){
        if(selecao == 1){
            selecao = 0;
        }else{
            selecao = 1;
        }
    }

    P1IFG &= ~(BIT1 + BIT3);
    P1IE |= BIT1 + BIT3;

    TA0CTL &= ~MC0;

}
