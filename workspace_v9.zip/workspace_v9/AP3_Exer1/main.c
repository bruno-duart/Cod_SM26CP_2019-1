#include <msp430.h> 

/*Implemente um cron�metro para medir intervalos de tempo entre 1s e 60 minutos, com resolu��o de
d�cimos e cent�simos de segundo (vari�veis minutos, dec_seg e cent_seg). Utilize a chave S2 (com
debouncer via Timer1) para iniciar/parar o cron�metro). O m�dulo 0 do Timer 0 deve ser utilizado para
determinar o per�odo entre os eventos estabelecidos por S2.
Ap�s o debouncer de S2, a a��o realizada na valida��o da tecla deve prever a comuta��o das
entradas do m�dulo 0 (via mux interno) entre GND e Vdd (o sinal da chave S2 n�o
deve entrar diretamente no m�dulo 0) para gerar borda (subida/descida) para a captura.
Neste exerc�cio � importante notar que entre a primeira captura e a segunda podem
haver �n� ciclos de contagem. Ent�o, para calcular o n�mero total de contagens � preciso
determinar �n� tamb�m. Para isso, � necess�rio habilitar a interrup��o do contador para
encontrar �n�, conforme a figura abaixo.
 */
#define MAX_CONT 65535

void ini_uCon(void);
void ini_P1_P2(void);
void ini_Timer(void);
void calculaTempo(void);

int minutos=0, dec_seg=0, cent_seg=0;
int segundos=0;
int cap1, val_anterior, val_atual, estado = -1;
char cap_ctrl = 0;
unsigned long TempoTotal = 0, Dif, ciclos = 0;

void main(){
    ini_uCon();
    ini_P1_P2();
    ini_Timer();
    while(1);
}

void ini_uCon(void){
    WDTCTL = WDTPW | WDTHOLD;                                                   //PARANDO O WDT

    DCOCTL = CALDCO_16MHZ;                                                      //MCLK = 16MHZ --> FREQUENCIA PR� CALIBRADA
    BCSCTL1 = CALBC1_16MHZ;                                                     //ACLK = 32768HZ (LFXT1) --> CRISTAL
    BCSCTL2 = DIVS0 + DIVS1;                                                    //SCLK = 2MHZ --> FATOR DE DIVISAO 8
    BCSCTL3 = XCAP0 + XCAP1;                                                    //C = 12pF --> CAPACITORES PARA O LFXT1

    while(BCSCTL3 & LFXT1OF);                                                   //SAI DO LOOP PARA LFXT1 EST�VEL

    __enable_interrupt();                                                       //HABILITA A GERA��O DE INTERRUP��ES
}

void ini_P1_P2(void){
    P1DIR = ~BIT3;
    P1IFG = 0;
    P1IE = P1IES = P1OUT = P1REN = BIT3;

    P2DIR = 0xFF;
    P2OUT = 0;
}

void ini_Timer(void){
    TA0CTL = TASSEL0 + MC1 + TAIE; // Modo cont�nuo de contagem. Clock ACLK = 32768
    TA0CCTL0 = CM0 + CM1 + CAP + CCIE + CCIS1 + CCIS0; // M�dulo 0: Captura
    /*TA0CCTL1 = CCIE;
    TA0CCR1 = 32767;
*/
    TA1CTL = TASSEL1;
    TA1CCTL0 = CCIE;
    TA1CCR0 = 19999;
}

void calculaTempo(void){
    segundos = TempoTotal/32768;
    dec_seg = (int)(TempoTotal % 32768)/3276;
    cent_seg =  (int)(TempoTotal % 32768) /3270;
    minutos = (int)segundos/60;

    /*segundos = (ciclos/**32768 + Dif*)/200000;
    minutos = segundos/60;*/
}

#pragma vector=PORT1_VECTOR
__interrupt void RTI_Chave_S2(void){
    P1IE &= ~BIT3;
    TA1CTL |= MC0 + TAIE;
}

#pragma vector=TIMER1_A0_VECTOR
__interrupt void RTI_Timer1_Debouncer(void){
    TA1CTL &= ~MC0;

    if(~P1IN & BIT3){
        TA0CCTL0 ^= CCIS0;  //dispara uma captura
        if(++estado == 2){     //mudan�a de estado
            segundos = minutos = dec_seg = cent_seg = 0;
            estado = -1;
        }
    }

    P1IFG &= ~BIT3;
    P1IE |= BIT3;
    TA1CTL &= ~(TAIE+TAIFG);
}

#pragma vector=TIMER0_A0_VECTOR
__interrupt void RTI_Timer0_Captura(void){
    /*val_atual = TA0CCR0;

    if(cap_ctrl > 0){
        if(val_atual > val_anterior)
            Dif = val_atual - val_anterior;
        else
            Dif = 65536 - val_anterior + val_atual;
    }

    cap_ctrl = 1;
    val_anterior = val_atual;*/
    if(estado == 0){
        //estados (0,2): reseta os valores e inicia a contagem
        cap1 = TA0CCR0;
        ciclos = 0;
    }
    else if(estado == 1){
        //estado (1): pausa a contagem e calcula o num. de ciclos
        TempoTotal = (MAX_CONT - cap1) + (ciclos-1)*MAX_CONT + TA0CCR0;
        //TempoTotal = ciclos-1)*MAX_CONT + TA0CCR0 - cap1;
        calculaTempo();
    }
}
#pragma vector=TIMER0_A1_VECTOR
__interrupt void RTI_Timer0_Contador(void){

    switch(TA0IV){
    case 2:
        break;
    case 4:
        break;
    case 10:
        ciclos++;
        break;
    }
    //TA0CTL &= TAIFG;
    //ciclos++;
}
