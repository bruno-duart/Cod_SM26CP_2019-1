#include <msp430.h>


void ini_uCon(void);
void ini_Portas(void);
void ini_TimerA(void);

/*
SENOIDE COM AMPLITUDE VARI�VEL POR UM ENCODER
O Duty-Cycle de um determinado pulso ser� dado por ((SIN_64[i] + 1)/2) * 100%
*/

char count = 0, dutyPercent = 100;


 //discretiza��o de uma senoide com amplitude zero*


const float SIN_64[] = {
    0.00000,
    0.09802,
    0.19509,
    0.29028,
    0.38268,
    0.47140,
    0.55557,
    0.63439,
    0.70711,
    0.77301,
    0.83147,
    0.88192,
    0.92388,
    0.95694,
    0.98079,
    0.99518,
    1.00000,
    0.99518,
    0.98079,
    0.95694,
    0.92388,
    0.88192,
    0.83147,
    0.77301,
    0.70711,
    0.63439,
    0.55557,
    0.47140,
    0.38268,
    0.29028,
    0.19509,
    0.09802,
    0.00000,
    -0.09802,
    -0.19509,
    -0.29028,
    -0.38268,
    -0.47140,
    -0.55557,
    -0.63439,
    -0.70711,
    -0.77301,
    -0.83147,
    -0.88192,
    -0.92388,
    -0.95694,
    -0.98079,
    -0.99518,
    -1.00000,
    -0.99518,
    -0.98079,
    -0.95694,
    -0.92388,
    -0.88192,
    -0.83147,
    -0.77301,
    -0.70711,
    -0.63439,
    -0.55557,
    -0.47140,
    -0.38268,
    -0.29028,
    -0.19509,
    -0.09802
};

// FUN��O PRINCIPAL
void main(void){
    ini_Portas();
    ini_uCon();
    ini_TimerA();


    do {
        _BIS_SR(LPM0_bits + GIE);
    }   while(1);
}


// CONFIG DE PORTAS
void ini_Portas(void){
    P1DIR = ~(BIT1 + BIT2);                                                     // BIT1 E BIT2 DA PORTA 1V COMO ENTRADAS DO ENCODER
    P1IE = P1IES = P1OUT = P1REN = BIT1 + BIT2;                                 // SAIDAS EM BAIXO, RESISTORES DESATIVADOS, INTERRUP��OES ATIVADAS POR BORDA DE DESCIDA

    P2DIR = 0xFF;                                                               //P2 TODOS OS BITS COMO SA�DA
    P2OUT = 0;                                                                  // P2 SAIDAS EM BAIXO PARA TODOS OS BITS
    P2SEL |= BIT2;                                                              // BIT 2 DA PORTA 2 COMO SAIDA DO PWM
    P2SEL2 &= ~BIT2;
}

// CONFIG DE INICIALIZA��O DO MICRO
void ini_uCon(void){
    WDTCTL = WDTPW | WDTHOLD;                                                   //PARANDO O WDT

    DCOCTL = CALDCO_16MHZ;                                                      //MCLK = 16MHZ --> FREQUENCIA PR� CALIBRADA
    BCSCTL1 = CALBC1_16MHZ;                                                     //ACLK = 32768HZ (LFXT1) --> CRISTAL
    BCSCTL2 = DIVS0 + DIVS1;                                                    //SCLK = 2MHZ --> FATOR DE DIVISAO 8
    BCSCTL3 = XCAP0 + XCAP1;                                                    //C = 12pF --> CAPACITORES PARA O LFXT1

    while(BCSCTL3 & LFXT1OF);                                                   //SAI DO LOOP PARA LFXT1 EST�VEL

    __enable_interrupt();                                                       //HABILITA A GERA��O DE INTERRUP��ES
}

// TIMERS
void ini_TimerA(void){

    //TIMER A0 -> DEBOUNCER
    TA0CTL = TASSEL0;                                                           // CLOCK -> ACLK, CONTAGEM INICIALMENTE PARADA
    TA0CCTL0 = CCIE;                                                            // INTERRUP��O DE CAPTURA/COMPARA��O ATIVADA
    TA0CCR0 = 15;                                                               // TACCR0 = t*Fclock/div - 1 = 500us*32768/1 - 1 = 15

    //TIMER A1 -> PWM
    TA1CTL = TASSEL1 + MC0 + TAIE;                                              // CLOCK -> SMCLK, MODO UP, INNTERRUP��O POR ESTOURO DE CONTAGEM ATIVADA
    TA1CCTL1 = OUTMOD0 + OUTMOD1 + OUTMOD2 + OUT;                               // MODE -> RESET/SET, OUT HIGHT
    TA1CCR0 = 780;                                                              // TACCR0 = (2MHz/(64*40Hz)) - 1 = 780
    TA1CCR1 = (int)((((float)SIN_64[count] + 1)/2)*TA1CCR0);                    // DUTY CYCLE inicia em 0%
}


// RTI PORTA 1
#pragma vector=PORT1_VECTOR
__interrupt void PORT1_RTI(void){
    P1IE &= ~(BIT1 + BIT2);                                                     // DESABILITA AS INTERRUPÇOES PARA EVITAR DUAS ENTRADAS CONSECUTIVAS
    TA0CTL |= MC0;                                                              // INICIA A CONTAGEM DO DEBOUNCER
}

/*Como o bit TAIE do registrador TA1CTL est� ativado(interrup��o por estouro de contagem), � provocada uma interrup��o
a cada vez que o contador faz um ciclo completo. Como o modo UP est� ativado, cada vez que o contador faz uma contagem completa
(de 0 at� TA1CCR0) � provocada uma interrupção e o valor de TAR � zerado*/

// RTI TIMER A1
#pragma vector=TIMER1_A1_VECTOR
__interrupt void PWM_RTI(void){
    count = (count + 1) % 64;                                                   // CALCULA O PROXIMO INDICE DO SENO
    TA1CCR1 = (int)((((float)SIN_64[count] + 1)/2)*TA1CCR0*dutyPercent/100);    // CALCULA O DUTY-CYCLE A PARTIR DO SENO, COM O PERCENTUAL DO ENCODER
    TA1CTL &= ~TAIFG;                                                           // LIMPA AS FLAGS
}

// RTI TIMER A0 -> DEBOUNCER
#pragma vector=TIMER0_A0_VECTOR
__interrupt void DEBOUNCER_RTI(void){
    TA0CTL &= ~MC0;                                                             // PARA A CONTAGEM DO DEBOUNCER


    switch(~P1IN & (BIT2 + BIT1)){
        case BIT1:
            if(dutyPercent > 0)                                                 //CICLO ATIVO N�O PODE SER MENOR QUE ZERO
                dutyPercent -= 5;
        break;
        case BIT2:
            if(dutyPercent < 100)                                               //CICLO ATIVO N�O PODE PASSAR DE 100%
                dutyPercent += 5;
        break;
    }

    P1IFG = 0;                                                                  // LIMPA FLAGS
    P1IE |= BIT1 + BIT2;                                                        // REABILITA AS INTERRUP��ES GERADAS PELO ENCODER
}
